
public class Appointment {
    private String date,time,vacType,vaccinator,ppsn;
    int vacNumber;

    public Appointment nextAppointment;

    public Appointment(String date, String time, String vacType, int vacNumber, String vaccinator, String ppsn){
        this.date=date;
        this.time=time;
        this.vacType=vacType;
        this.vacNumber=vacNumber;
        this.vaccinator=vaccinator;
        this.ppsn=ppsn;
    }


    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getVacType() {
        return vacType;
    }

    public void setVacType(String vacType) {
        this.vacType = vacType;
    }

    public int getVacNumber() {
        return vacNumber;
    }

    public void setVacNumber(int vacNumber) {
        this.vacNumber = vacNumber;
    }

    public String getVaccinator() {
        return vaccinator;
    }

    public void setVaccinator(String vaccinator) {
        this.vaccinator = vaccinator;
    }

    public String getPpsn() {
        return ppsn;
    }

    public void setPpsn(String ppsn) {
        this.ppsn = ppsn;
    }

    public String vacRecord() {
        return "Appointment details:" +
                "date=" + date +
                ", time=" + time +
                ", vaccination type=" + vacType +
                ", vaccination number=" + vacNumber +
                ", vaccinator=" + vaccinator +
                ", PPS number=" + ppsn;
    }
}
