
public class Centre {

    private String vacName,vacAddress,eircode;
    private int parkingSpaces;

    public Centre nextCentre;
    public Booth headBooth;

    public Centre(String vacName, String vacAddress,String eircode, int parkingSpaces){
        this.vacName=vacName;
        this.vacAddress=vacAddress;
        this.eircode=eircode;
        this.parkingSpaces=parkingSpaces;
    }


    public String getName() {
        return vacName;
    }

    public void setName(String vacName) {
        this.vacName = vacName;
    }

    public String getAddress() {
        return vacAddress;
    }

    public void setAddress(String vacAddress) {
        this.vacAddress = vacAddress;
    }

    public String getEircode() {
        return eircode;
    }

    public void setEircode(String eircode) {
        this.eircode = eircode;
    }

    public int getParkingSpaces() {
        return parkingSpaces;
    }

    public void setParkingSpaces(int parkingSpaces) {
        this.parkingSpaces = parkingSpaces;
    }

    @Override
    public String toString() {
        return "Vaccination centre:" +
                "Name=" + vacName +
                ", address=" + vacAddress +
                ", eircode=" + eircode +
                ", number of parking spaces=" + parkingSpaces;
    }
}
