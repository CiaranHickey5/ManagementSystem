import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.DomDriver;
import com.thoughtworks.xstream.security.AnyTypePermission;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;

public class Main {



    //Calling the head of all vaccination centres, booths and appointments
    public static Centre headCentre;

    Scanner input=new Scanner(System.in);

    public static void main(String[] args) throws Exception {
        Main m=new Main();
        m.runMenu();
    }


//This is the menu which is presented to the user when the program is first run
    private int mainMenu(){
        System.out.println("Vaccination centre menu");
        System.out.println("-----------------------------------------");
        System.out.println(" 1) Add a vaccination centre");
        System.out.println(" 2) Add a vaccination booth");
        System.out.println(" 3) Add a vaccination appointment");
        System.out.println(" 4) Add a patient");
        System.out.println("-----------------------------------------");
        System.out.println(" 5) Display all vaccination centres");
        System.out.println(" 6) Display all vaccination booths");
        System.out.println(" 7) Display all vaccination appointments");
        System.out.println(" 8) Display all patients");
        System.out.println(" 9) Display patient by their pps number");
        System.out.println("-----------------------------------------");
        System.out.println(" 10) Delete a vaccination centre");
        System.out.println(" 11) Delete a vaccination booth");
        System.out.println(" 12) Delete a vaccination appointment");
        System.out.println(" 13) Delete a patient");
        System.out.println("-----------------------------------------");
        System.out.println(" 14) Save");
        System.out.println(" 15) Load");
        System.out.println("-----------------------------------------");
        System.out.println(" 16) Clear all data");
        System.out.println("-----------------------------------------");
        System.out.println(" 17) Complete an appointment");
        System.out.println(" 18) Display all vaccination records");
        System.out.println(" 19) Search for vaccination by type, batch number, completed and pending.");
        System.out.println("-----------------------------------------");
        System.out.println(" 0) Exit");
        System.out.print("Enter option: ");
        int option=input.nextInt();
        return option;
    }

    //Depending on the number that the user enters, a method is called from the run menu
    private void runMenu() throws Exception{
        int option=mainMenu();
        while(option!=0){
            switch (option){
                case 1: addCentre();
                break;
                case 2: addBooth();
                break;
                case 3: addAppointment();
                break;
                case 4: addPatient();
                break;
                case 5: printCentre();
                break;
                case 6: printBooth();
                break;
                case 7: printAppointment();
                break;
                case 8: printPatient();
                break;
                case 9: patientByPPS();
                break;
                case 10: deleteCentre();
                break;
                case 11: deleteBooth();
                break;
                case 12: deleteAppointment();
                break;
                case 13: deletePatient();
                break;
                case 14: save();
                break;
                case 15: load();
                break;
                case 16: clearAll();
                break;
                case 17: completeAppointment();
                break;
                case 18: printRecord();
                break;
                case 19: vacSearch();
                break;

                default:
                    System.out.println("Invalid input entered");
            }
            System.out.println("\nPress any key to continue...");
            input.nextLine();
            input.nextLine();
            option = mainMenu();
        }
        System.out.println("Exiting... bye");
        System.exit(0);
    }

    //This method adds a vaccination centre to the system
    public void addCentre(){
        input.nextLine();
        System.out.println("Enter the vaccination centre name: ");
        String vacName = input.nextLine();
        System.out.println("Enter the vaccination centre address: ");
        String vacAddress=input.nextLine();
        System.out.println("Enter the vaccination centre eircode: ");
        String eircode=input.nextLine();
        System.out.println("Enter the number of parking spaces: ");
        int parkingSpaces=input.nextInt();
        Centre vacCentre=new Centre(vacName,vacAddress,eircode,parkingSpaces);

        Centre currentCentre=headCentre;
        if(headCentre==null){
            headCentre=vacCentre;
        }
        else{
            while(currentCentre.nextCentre!=null){
                currentCentre=currentCentre.nextCentre;
            }
            currentCentre.nextCentre=vacCentre;
        }
    }

    //This method adds a vaccination booth to the system
    public void addBooth(){
        input.nextLine();
        printCentre();
        System.out.println("Enter the name of the vaccination centre: ");
    String centreName = input.nextLine();
    Centre foundCentre=findCentre(centreName);
        if (foundCentre!=null) {
        System.out.println("Enter the booth identifier: ");
        String identifier = input.nextLine();
        System.out.println("Enter the booth floor level(Number): ");
        int floorLevel = input.nextInt();
        input.nextLine();
        System.out.println("Enter the booth accessibility: ");
        String accessibility = input.nextLine();
        Booth booth = new Booth(identifier, floorLevel, accessibility);
        booth.nextBooth = foundCentre.headBooth;
        foundCentre.headBooth = booth;
    }
        else{
        System.out.println("Invalid vaccination centre entered");
    }

}

//This method add an appointment to the system
    public void addAppointment() {
        input.nextLine();
        printPatient();
        System.out.println("Enter your PPSN:");
        String patientPPSN = input.nextLine();
        Patient foundPatient=findPatient(patientPPSN);
         if (foundPatient != null) {
            input.nextLine();
            printCentre();
            System.out.println("Enter name of the vaccination centre: ");
            String centerName = input.nextLine();
            Centre foundCentre = findCentre(centerName);
            if (foundCentre != null) {
                printBooth();
                System.out.println("Enter the booth identifier: ");
                String boothName = input.nextLine();
                Booth foundBooth = findBooth(boothName);
                if (foundBooth != null) {
                    input.nextLine();
                    System.out.println("Enter the date of appointment: ");
                    String date = input.nextLine();
                    System.out.println("Enter the time of appointment: ");
                    String time = input.nextLine();
                    System.out.println("Enter the vaccination type: ");
                    String vacType = input.nextLine();
                    System.out.println("Enter the vaccination number: ");
                    int vacNumber = input.nextInt();
                    System.out.println("Enter the name of the vaccinator: ");
                    String vaccinator = input.next();
                    input.nextLine();
                    Appointment appointment = new Appointment(date, time, vacType, vacNumber, vaccinator, patientPPSN);
                    appointment.nextAppointment = foundBooth.headAppointment;
                    foundBooth.headAppointment = appointment;
                } else {
                    System.out.println("Invalid booth identifier entered: ");
                }
            } else {
                System.out.println("Invalid vaccination centre entered");
            }
        }
        else{
            System.out.println("Invalid patient name entered");
        }
    }

    //This method adds a patient to the system
    public void addPatient(){
        input.nextLine();
        System.out.println("Enter your PPSN: ");
        String ppsn=input.nextLine();
        System.out.println("Enter your full name: ");
        String name=input.nextLine();
        System.out.println("Enter your date of birth: ");
        String dob= input.nextLine();
        System.out.println("Enter your address: ");
        String address=input.nextLine();
        System.out.println("Enter any accessibility-related information: ");
        String accessibility=input.nextLine();
        Patient patient=new Patient(ppsn,name,dob,address,accessibility);
        patient.nextPatient= patient.headPatient;
        patient.headPatient=patient;
    }

    //This method finds a vaccination centre from the name entered
    public Centre findCentre(String centreName){
        Centre currentNode=headCentre;
        while(currentNode!=null){
            if(currentNode.getName().equals(centreName)){
                return currentNode;
            }
            currentNode=currentNode.nextCentre;
        }
        return null;
}

    //This method finds a vaccination booth from the name entered
    public Booth findBooth(String boothName){
        Booth currentNode= headCentre.headBooth;
        while(currentNode!=null){
            if(currentNode.getIdentifier().equals(boothName)){
                return currentNode;
            }
            currentNode=currentNode.nextBooth;
        }
        return null;
    }

    //This method finds a vaccination appointment from the pps number entered
    public Appointment findAppointment(String ppsn){
        Appointment currentNode=headCentre.headBooth.headAppointment;
        while(currentNode!=null){
            if(currentNode.getPpsn().equals(ppsn)){
                return currentNode;
            }
            currentNode=currentNode.nextAppointment;
        }
        return null;
    }

    //This method finds a patient from the pps number entered
    public Patient findPatient(String patientPPSN){
        Patient currentNode = Patient.headPatient;
        while(currentNode!=null){
            if(currentNode.getPpsn().equals(patientPPSN)){
                return currentNode;
            }
            currentNode=currentNode.nextPatient;
        }
        return null;
    }

    public boolean deleteFoundCentre(Centre centreToFind){
        if(headCentre!=null){
            Centre currentCentre = headCentre;
            if(centreToFind==currentCentre){
                headCentre=null;
            }
            while(currentCentre!=null){
                if(currentCentre.nextCentre==centreToFind){
                    currentCentre.nextCentre=currentCentre.nextCentre.nextCentre;
                }
                currentCentre=currentCentre.nextCentre;
            }
        }
        else {
            return false;
        }
        return false;
    }

    public boolean deleteFoundBooth(Booth boothToFind){
        return false;
    }

        public boolean deleteFoundAppointment(Appointment appToFind){
        if(headCentre.headBooth.headAppointment!=null){

        }
        else{
            System.out.println("No appointments found");
        }
        return false;
    }

    //This method displays all vaccination centres in the system
    public void printCentre(){
        System.out.println("Here is the list of vaccination centres: \n");
        Centre currentCentre=headCentre;
        while(currentCentre!=null){
            System.out.println(currentCentre);
            currentCentre=currentCentre.nextCentre;
        }
    }

    //This method displays all vaccination booths in the system
    public void printBooth(){
        input.nextLine();
        printCentre();
        System.out.println("Enter the vaccination centre: ");
        String centerName = input.nextLine();
        Centre foundCentre=findCentre(centerName);
        if(foundCentre!=null){
            System.out.println("Here is the list of booths in the vaccination centre: \n");
            Booth currentBooth = foundCentre.headBooth;
            while(currentBooth!=null){
                System.out.println(currentBooth);
                currentBooth=currentBooth.nextBooth;
            }
        }
        else{
            System.out.println("Invalid vaccination centre entered");
        }
    }

    //This method asks the user to enter 1 or 2 and runs the chosen method
    public void printAppointment() {
        input.nextLine();
        System.out.println("Press 1 to view appointments in a specific vaccination centre");
        System.out.println("Press 2 to view all appointments in the system");
        int choice = input.nextInt();
        switch (choice) {
            case 1:
                centreAppointment();
                break;
            case 2:
                systemAppointment();
                break;
            default:
                System.out.println("Invalid input entered");
        }
    }

    //This method displays all appointments in a specific vaccination centre
        public void centreAppointment(){
            input.nextLine();
            printCentre();
            System.out.println("Enter the name of the vaccination centre");
            String centreName=input.nextLine();
            Centre foundCentre = findCentre(centreName);
            if(foundCentre!=null){
                System.out.println("Here is the list of booths in the vaccination centre: \n");
                Booth currentBooth = foundCentre.headBooth;
                while(currentBooth!=null){
                    System.out.println(currentBooth);
                    while(currentBooth.headAppointment!=null){
                        System.out.println(currentBooth.headAppointment.vacRecord());
                        currentBooth.headAppointment=currentBooth.headAppointment.nextAppointment;
                    }
                    currentBooth=currentBooth.nextBooth;
                }
            }
            else{
                System.out.println("Invalid vaccination centre entered");
            }
        }

        //This method displays all appointments in the system
        public void systemAppointment(){
            Centre currentCentre=headCentre;
            while(currentCentre!=null){
                System.out.println(currentCentre);
                Booth currentBooth= currentCentre.headBooth;
                while (currentBooth != null) {
                    System.out.println(currentBooth);
                    Appointment currentAppointment= currentBooth.headAppointment;
                    while(currentAppointment!=null){
                        System.out.println(currentAppointment.vacRecord());
                        currentAppointment=currentAppointment.nextAppointment;
                    }
                    currentBooth=currentBooth.nextBooth;
                }
                currentCentre=currentCentre.nextCentre;
            }
        }


//This method displays all patients in the system
    public void printPatient(){
        input.nextLine();
        System.out.println("Here is the list of patients: \n");
        Patient currentPatient= Patient.headPatient;
        while(currentPatient!=null){
            System.out.println(currentPatient);
            currentPatient=currentPatient.nextPatient;

        }
    }

    //This method displays all vaccination records in the system
    public void printRecord(){
        input.nextLine();
        System.out.println("Here is the list of vaccination records: \n");
        VacRecord currentRecord= VacRecord.headRecord;
        while(currentRecord!=null){
            System.out.println(currentRecord);
            currentRecord=currentRecord.nextRecord;
        }
    }

    //This method searches for a patient from their pps number
    public void patientByPPS(){
        System.out.println("Enter your PPS number");
        input.nextLine();
        String patientPPS=input.nextLine();
        Patient foundPatient=findPatient(patientPPS);
        if(foundPatient!=null)
            System.out.println(foundPatient);
    }

//This method removes a vaccination centre from the system
    public void deleteCentre(){
        input.nextLine();
        System.out.println("Enter the position of the centre");
        int pos = input.nextInt();
        Centre currentCentre=headCentre;
        int i=0;
        while(i<pos-1 && currentCentre!=null){
            currentCentre=currentCentre.nextCentre;
            i++;
        }
        //Making the headCentre null when the headCentre is the only element in the linkedList
        if(currentCentre!=null&&currentCentre.nextCentre==null&&pos==0){
            headCentre=null;
        }
        //Making the headCentre the nextCentre when there is a nextCentre
        else if(currentCentre!=null && currentCentre.nextCentre!=null&&pos==0){
            headCentre=currentCentre.nextCentre;
        }
        //Making the nextCentre, the nextCentre's nextCentre
        else if(currentCentre!=null && currentCentre.nextCentre!=null&&pos!=0){
            currentCentre.nextCentre=currentCentre.nextCentre.nextCentre;
        }
    }

    //This method removes a vaccination booth from the system
    public void deleteBooth(){
        input.nextLine();
        printCentre();
        System.out.println("Enter the name of the vaccination centre");
        String centreName = input.nextLine();
        Centre foundCentre = findCentre(centreName);
        if(foundCentre!=null){
            printBooth();
            System.out.println("Enter the position of the booth");
            int pos = input.nextInt();
            int i = 0;
            Booth currentBooth = foundCentre.headBooth;
            while(i<pos-1 && currentBooth!=null){
                currentBooth=currentBooth.nextBooth;
                i++;
            }
            //Making the headBooth null when the headBooth is the only element in the linkedList
            if(currentBooth!=null&&currentBooth.nextBooth==null&&pos==0){
                foundCentre.headBooth=null;
            }
            //Making the headBooth the nextBooth when there is a nextBooth
            else if(currentBooth!=null && currentBooth.nextBooth!=null&&pos==0){
                foundCentre.headBooth=currentBooth.nextBooth;
            }
            //Making the nextBooth, the nextBooth's nextBooth
            else if(currentBooth!=null && currentBooth.nextBooth!=null&&pos!=0){
                currentBooth.nextBooth=currentBooth.nextBooth.nextBooth;
            }
        }
        else{
            System.out.println("Invalid vaccination centre name entered");
        }
    }

    //This method deletes an appointment from the system
    public void deleteAppointment(){
        input.nextLine();
        printCentre();
        System.out.println("Enter the name of the vaccination centre");
        String centreName = input.nextLine();
        Centre foundCentre = findCentre(centreName);
        if(foundCentre!=null){
            printBooth();
            System.out.println("Enter the booth identifier");
            String identifier = input.nextLine();
            Booth foundBooth = findBooth(identifier);
            if(foundBooth!=null){
                systemAppointment();
                System.out.println("Enter the position of the appointment");
                int pos=input.nextInt();
                int i=0;
                Appointment currentAppointment = foundBooth.headAppointment;
                while(currentAppointment!=null && i<pos-1){
                    currentAppointment = currentAppointment.nextAppointment;
                    i++;
                }
                //Making the headAppointment null when the headAppointment is the only element in the linkedList
                if(currentAppointment!=null&&currentAppointment.nextAppointment==null&&pos==0){
                    foundCentre.headBooth.headAppointment=null;
                }
                //Making the headAppointment the nextAppointment when there is a nextAppointment
                else if(currentAppointment!=null && currentAppointment.nextAppointment!=null&&pos==0){
                    foundCentre.headBooth.headAppointment=currentAppointment.nextAppointment;
                }
                //Making the nextAppointment, the nextAppointment's nextAppointment
                else if(currentAppointment!=null && currentAppointment.nextAppointment!=null&&pos!=0){
                    currentAppointment.nextAppointment=currentAppointment.nextAppointment.nextAppointment;
                }
            }
            else{
                System.out.println("Invalid vaccination booth entered");
            }
        }
        else{
            System.out.println("Invalid vaccination centre name entered");
        }
    }

    //This method deletes a patient from the system
    public void deletePatient(){
        input.nextLine();
        printPatient();
        System.out.println("Enter the position of the patient");
        int pos=input.nextInt();
        Patient currentPatient = Patient.headPatient;
        int i=0;
        while(i<pos-1 && currentPatient!=null){
            currentPatient=currentPatient.nextPatient;
            i++;
        }
        if(currentPatient!=null && currentPatient.nextPatient!=null){
            currentPatient.nextPatient = currentPatient.nextPatient.nextPatient;
        }

    }

    //This method clears all data from the system
    public void clearAll(){
        headCentre=null;
        Patient.headPatient=null;
    }

    //This method saves data onto a xml file
    public void save()throws Exception{
        XStream xStream = new XStream(new DomDriver());

        ObjectOutputStream out = xStream.createObjectOutputStream(new FileWriter("vaccination.xml"));
        out.writeObject(headCentre);
        out.writeObject(Patient.headPatient);
        out.close();
    }

    //This method loads the xml file
    public void load() throws Exception{
        XStream xStream = new XStream(new DomDriver());
        xStream.addPermission(AnyTypePermission.ANY);
        ObjectInputStream is = xStream.createObjectInputStream(new FileReader("vaccination.xml"));
        headCentre=(Centre)is.readObject();
        Patient.headPatient=(Patient)is.readObject();
    }

    //This method generates a vaccination record and removes the appointment from the system
    public void completeAppointment(){
        input.nextLine();
        printPatient();
        System.out.println("Enter your pps number");
        String ppsn=input.nextLine();
        Appointment foundAppointment=findAppointment(ppsn);
        if(ppsn!=null) {
            String date = foundAppointment.getDate();
            String time = foundAppointment.getTime();
            String vacType = foundAppointment.getVacType();
            int vacNumber = foundAppointment.vacNumber;
            String vaccinator = foundAppointment.getVaccinator();
            VacRecord vacRecord = new VacRecord(ppsn, vacType, vaccinator, time, date, vacNumber);
            vacRecord.nextRecord = VacRecord.headRecord;
            VacRecord.headRecord = vacRecord;
            System.out.println("Here is your vaccination record \n");
            System.out.println(vacRecord);
            //Loop through all centres and booths and stop at appointment before foundAppointment.
            //When stopped 1 appointment before,make the nextAppointment the next.nextAppointment, this deletes the foundAppointment.
            Centre currentCentre = headCentre;
            while (currentCentre != null) {
                Booth currentBooth = currentCentre.headBooth;
                while(currentBooth!=null){
                    Appointment currentAppointment = currentBooth.headAppointment;
                    if(currentAppointment.nextAppointment==foundAppointment){
                        if(currentAppointment.nextAppointment.nextAppointment.nextAppointment!=null) {
                            currentAppointment.nextAppointment.nextAppointment = currentAppointment.nextAppointment.nextAppointment.nextAppointment;
                        }
                        while(currentAppointment!=null){
                            currentAppointment = currentAppointment.nextAppointment;
                        }
                    }
                    currentBooth = currentBooth.nextBooth;
                }
                currentCentre = currentCentre.nextCentre;
            }
        }
        else{
            System.out.println("Invalid pps number entered");
        }


    }

    //This method searches for vaccination by type, batch, completed and pending vaccinations
    public void vacSearch(){
        input.nextLine();
        System.out.println("Press 1 to search for vaccinations by type");
        System.out.println("Press 2 to search for vaccinations by batch");
        int option=input.nextInt();
        if(option==1){
            System.out.println("Press 1 to search for completed vaccinations");
            System.out.println("Press 2 to search for pending vaccinations");
            int choice=input.nextInt();
            switch (choice){
                case 1:
                    typeCompletedSearch();
                    break;
                case 2:
                    typePendingSearch();
                default:
                    System.out.println("Invalid input entered");
            }
        }
        else if(option==2){
            System.out.println("Press 1 to search for completed vaccinations");
            System.out.println("Press 2 to search for pending vaccinations");
            int choice=input.nextInt();
            switch (choice){
                case 1:
                    batchCompletedSearch();
                    break;
                case 2:
                    batchPendingSearch();
                default:
                    System.out.println("Invalid input entered");
            }
        }
        else{
            System.out.println("Invalid input entered");
        }
    }

    //This method finds a vaccination record from the vaccination type entered
    public VacRecord findRecordType(String type){
        VacRecord currentNode = VacRecord.headRecord;
        while(currentNode!=null){
            if(currentNode.getVacType().equals(type)){
                return currentNode;
            }
            currentNode=currentNode.nextRecord;
        }
        return null;
    }

    //This method finds a vaccination record from the vaccination batch number entered
    public VacRecord findRecordNumber(int number){
        VacRecord currentNode = VacRecord.headRecord;
        while(currentNode!=null){
            if(currentNode.getVacNumber()==(number)){
                return currentNode;
            }
            currentNode=currentNode.nextRecord;
        }
        return null;
    }

    public void typeCompletedSearch(){
        input.nextLine();
        printRecord();
        input.nextLine();
        System.out.println("Please enter the type of vaccination");
        String vacType=input.nextLine();
        VacRecord foundVacType = findRecordType(vacType);
        if(foundVacType!=null){
            System.out.println(foundVacType);
        }
        else{
            System.out.println("Invalid vaccination type entered");
        }
    }

    public void typePendingSearch(){
        input.nextLine();
        systemAppointment();
        input.nextLine();
        System.out.println("Please enter your ppsn");
        String ppsn=input.nextLine();
        Appointment foundppsn=findAppointment(ppsn);
        if(foundppsn!=null){
            System.out.println(foundppsn.getVacType());
        }
        else{
            System.out.println("Invalid ppsn entered");
        }
    }

    public void batchCompletedSearch(){
        input.nextLine();
        printRecord();
        input.nextLine();
        System.out.println("Please enter the batch number of the vaccination");
        int vacNumber=input.nextInt();
        VacRecord foundVacNumber = findRecordNumber(vacNumber);
        if(foundVacNumber!=null){
            System.out.println(foundVacNumber);
        }
        else{
            System.out.println("Invalid vaccination type entered");
        }
    }

    public void batchPendingSearch(){
        input.nextLine();
        systemAppointment();
        input.nextLine();
        System.out.println("Please enter your ppsn");
        String ppsn=input.nextLine();
        Appointment foundppsn=findAppointment(ppsn);
        if(foundppsn!=null){
            System.out.println(foundppsn.getVacNumber());
        }
        else{
            System.out.println("Invalid ppsn entered");
        }
    }

}
