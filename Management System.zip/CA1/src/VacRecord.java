public class VacRecord {
    private String ppsn, vaccinator, vacType, time, date;
    int vacNumber;
    public static VacRecord headRecord;
    public VacRecord nextRecord;


    public VacRecord(String ppsn, String vacType, String vaccinator, String time, String date, int vacNumber) {
        this.ppsn = ppsn;
        this.vacType = vacType;
        this.vaccinator = vaccinator;
        this.time = time;
        this.date = date;
        this.vacNumber = vacNumber;
    }

    public String getPpsn() {
        return ppsn;
    }

    public void setPpsn(String ppsn) {
        this.ppsn = ppsn;
    }

    public String getVaccinator() {
        return vaccinator;
    }

    public void setVaccinator(String vaccinator) {
        this.vaccinator = vaccinator;
    }

    public String getVacType() {
        return vacType;
    }

    public void setVacType(String vacType) {
        this.vacType = vacType;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public int getVacNumber() {
        return vacNumber;
    }

    public void setVacNumber(int vacNumber) {
        this.vacNumber = vacNumber;
    }

    public String toString(){
        return "Vaccination card for pps number: " + ppsn +
                ". You received your " + vacType + " vaccine from " + vaccinator + " at "+time +" on "+ date +
                ". Your vaccination number is " + vacNumber;
    }
}
