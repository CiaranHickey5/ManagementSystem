
public class Booth {

    private String identifier,accessibility;
    private int floorLevel;

    public Booth nextBooth;
    public Appointment headAppointment;

    public Booth(String identifier, int floorLevel, String accessibility){
        this.identifier=identifier;
        this.floorLevel=floorLevel;
        this.accessibility=accessibility;
    }



    public String getIdentifier() {
        return identifier;
    }

    public void setIdentifier(String identifier) {
        this.identifier = identifier;
    }

    public String getAccessibility() {
        return accessibility;
    }

    public void setAccessibility(String accessibility) {
        this.accessibility = accessibility;
    }

    public int getFloorLevel() {
        return floorLevel;
    }

    public void setFloorLevel(int floorLevel) {
        this.floorLevel = floorLevel;
    }

    @Override
    public String toString() {
        return "Vaccination booth:" +
                "Identifier=" + identifier +
                ", accessibility=" + accessibility +
                ", floor level=" + floorLevel;
    }
}
