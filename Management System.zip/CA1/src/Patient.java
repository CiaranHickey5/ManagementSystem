
public class Patient {

    private String ppsn, name, dob, address, accessibility;

    public static Patient headPatient;
    public Patient nextPatient;

    public Patient(String ppsn, String name, String dob, String address, String accessibility){
        this.ppsn=ppsn;
        this.name=name;
        this.dob=dob;
        this.address=address;
        this.accessibility=accessibility;
    }

    public String getPpsn() {
        return ppsn;
    }

    public void setPpsn(String ppsn) {
        if(ppsn.length()>9||ppsn.length()<8){
            this.ppsn=ppsn.substring(0,9);
            System.out.println("Invalid pps number entered");
        }
        else{
            this.ppsn=ppsn;
        }
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if(name.length()>20){
            this.name=name.substring(0,20);
        }
        else{
            this.name=name;
        }
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        if(dob.length()>9){
            this.dob=dob.substring(0,10);
        }
        else{
            this.dob=dob;
        }
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        if(address.length()>25) {
            this.address = address.substring(0,25);
        }
        else{
            this.address=address;
        }
    }

    public String getAccessibility() {
        return accessibility;
    }

    public void setAccessibility(String accessibility) {
        this.accessibility = accessibility;
    }

    public Patient findPatient(String patientName){
        Patient currentNode = headPatient;
        while (currentNode != null) {
            if(currentNode.getName().equals(patientName)){
                return currentNode;
            }
            currentNode=currentNode.nextPatient;
        }
        return null;
    }

    @Override
    public String toString() {
        return "Patient details:" +
                "PPS number=" + ppsn +
                ", name=" + name +
                ", date of birth=" + dob +
                ", address=" + address +
                ", accessibility=" + accessibility;
    }
}
