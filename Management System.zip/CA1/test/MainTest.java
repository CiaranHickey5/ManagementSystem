import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class MainTest {

    @org.junit.jupiter.api.BeforeEach
    //Before creating any tests, a patient is created.
    void setUp() {
        Patient p = new Patient("1823748NA","Ciaran Hickey", "05/11/2000", "Waterford, Ireland", "None");
        Patient.headPatient=p;
    }

    @org.junit.jupiter.api.AfterEach
    void tearDown() {
    }

    @Test
    public void getPatientPPSN(){
        assertEquals("1823748NA", Patient.headPatient.getPpsn());
    }

    //This test uses a substring to allow a maximum of 9 characters in length for the patient pps number
    @Test
    public void setPatientPPSN(){
        Patient.headPatient.setPpsn("321321321321321321321");
        assertEquals("321321321", Patient.headPatient.getPpsn());
        Patient.headPatient.setPpsn("1234567891");
        assertEquals("123456789",Patient.headPatient.getPpsn());
    }

    @Test
    public void getPatientName(){
        assertEquals("Ciaran Hickey",Patient.headPatient.getName());
    }

    //This test uses a substring to allow a maximum of 20 characters for the patient name
    @Test
    public void setPatientName(){
        Patient.headPatient.setName("Joe Biden");
        assertEquals("Joe Biden", Patient.headPatient.getName());
        Patient.headPatient.setName("Michael Jordan Michael Jordan");
        assertEquals("Michael Jordan Micha", Patient.headPatient.getName());
    }

    @Test
    public void getPatientDOB(){
        assertEquals("05/11/2000", Patient.headPatient.getDob());
    }

    //This test uses a substring to allow a maximum of 9 characters in length.
    // This doesn't allow any short or long entries to be made.
    @Test
    public void setPatientDOB(){
        Patient.headPatient.setDob("17/03/1984");
        assertEquals("17/03/1984", Patient.headPatient.getDob());
        Patient.headPatient.setDob("01/01/20011");
        assertEquals("01/01/2001", Patient.headPatient.getDob());
    }

    @Test
    public void getPatientAddress(){
        assertEquals("Waterford, Ireland", Patient.headPatient.getAddress());
    }

    //This test uses a substring to allow a maximum of 25 characters in length.
    @Test
    public void setPatientAddress(){
        Patient.headPatient.setAddress("Dublin, Ireland");
        assertEquals("Dublin, Ireland", Patient.headPatient.getAddress());
        Patient.headPatient.setAddress("10 Downing Street, London, England");
        assertEquals("10 Downing Street, London", Patient.headPatient.getAddress());
    }

    @Test
    public void getPatientAccessibility(){
        assertEquals("None", Patient.headPatient.getAccessibility());
    }

    @Test
    public void setPatientAccessibility(){
        Patient.headPatient.setAccessibility("Wheelchair");
        assertEquals("Wheelchair", Patient.headPatient.getAccessibility());
    }
}